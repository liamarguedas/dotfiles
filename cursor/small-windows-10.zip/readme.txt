﻿=== Small Windows 10 Cursor Set ===

By: Lihpe25 (http://www.rw-designer.com/user/94779) walissonfelipe3125@gmail.com

Download: http://www.rw-designer.com/cursor-set/small-windows-10

Author's description:

it took a while but i finally managed to do another course it took a bit of work i hope you like it!


==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.